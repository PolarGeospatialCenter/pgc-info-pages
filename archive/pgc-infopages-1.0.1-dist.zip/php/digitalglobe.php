<?php
echo file_get_contents('http://repository.agic.umn.edu/website/infopages/DigitalGlobe_Count.json');
?>